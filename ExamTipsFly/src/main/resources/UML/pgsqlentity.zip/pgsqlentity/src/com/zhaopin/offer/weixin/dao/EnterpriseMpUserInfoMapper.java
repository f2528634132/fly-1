package com.zhaopin.offer.weixin.dao;

import com.zhaopin.offer.weixin.entity.EnterpriseMpUserInfo;

public interface EnterpriseMpUserInfoMapper {
    int deleteByPrimaryKey(String id);

    int insert(EnterpriseMpUserInfo record);

    int insertSelective(EnterpriseMpUserInfo record);

    EnterpriseMpUserInfo selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(EnterpriseMpUserInfo record);

    int updateByPrimaryKey(EnterpriseMpUserInfo record);
}